import * as sdk from '@botpress/sdk'

export const events = {} as const satisfies sdk.IntegrationDefinitionProps['events']
