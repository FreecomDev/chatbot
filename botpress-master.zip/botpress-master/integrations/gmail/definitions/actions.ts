import * as sdk from '@botpress/sdk'

export const actions = {} as const satisfies sdk.IntegrationDefinitionProps['actions']
