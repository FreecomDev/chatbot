export const MS_IN_12_HOURS = 43_200_000 as const
