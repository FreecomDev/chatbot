import * as bp from '.botpress'

export const actions = {} as const satisfies bp.IntegrationProps['actions']
