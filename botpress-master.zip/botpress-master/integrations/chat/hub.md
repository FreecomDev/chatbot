The Chat integration allows you to chat with your bot using HTTP requests. Check out the [documentation](https://botpress.com/reference/introduction) for more information.
