import { channel } from './channel'
import * as bp from '.botpress'

export default {
  channel,
} satisfies bp.IntegrationProps['channels']
