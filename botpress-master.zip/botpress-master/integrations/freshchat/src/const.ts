export const INTEGRATION_NAME = 'freshchat'
