import { IntegrationDefinitionProps } from '@botpress/sdk'

export const channels = undefined satisfies IntegrationDefinitionProps['channels']
