import * as bp from '.botpress'

export const channels: bp.IntegrationProps['channels'] = async () => {}
