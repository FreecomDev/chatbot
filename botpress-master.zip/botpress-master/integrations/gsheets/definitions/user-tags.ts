import * as sdk from '@botpress/sdk'

export const user = {} as const satisfies sdk.IntegrationDefinitionProps['user']
