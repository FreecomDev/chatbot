import * as sdk from '@botpress/sdk'

export const channels = {} as const satisfies sdk.IntegrationDefinitionProps['channels']
