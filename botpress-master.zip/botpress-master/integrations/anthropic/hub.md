# Anthropic Integration

This integration allows your bot to choose from a curated list of Claude models from [Anthropic](https://docs.anthropic.com/en/docs/about-claude/models) as the LLM of your choice for a node, workflow, or skill in your bot.

Usage is charged to the AI Spend of your workspace in Botpress Cloud at the [same pricing](https://www.anthropic.com/pricing) (at cost) as directly with Anthropic.
