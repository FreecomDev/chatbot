# Groq Integration

This integration allows your bot to choose from a curated list of models from [Groq](https://groq.com/) for content generation and chat completions (LLM) and audio transcription (speech-to-text).

Usage is charged to the AI Spend of your workspace in Botpress Cloud at the [same pricing](https://wow.groq.com/) (at cost) as directly with Groq.
