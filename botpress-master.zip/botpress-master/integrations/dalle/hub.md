# Dalle (Deprecated)

**Note:** This integration is deprecated in favor of [this one](https://app.botpress.cloud/hub/integrations/intver_01HX9TS0ZX98NAE1AR3D2QBPKM), maintained by _[Simply Great Bots](https://app.botpress.cloud/simplygreatbots)_. We encourage you to install it for better maintenance.
