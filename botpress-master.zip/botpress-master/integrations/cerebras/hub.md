# Cerebras Integration

This integration allows your bot to choose from a curated list of models from [Cerebras](https://cerebras.ai/developers/) for content generation and chat completions.

Usage is charged to the AI Spend of your workspace in Botpress Cloud at the same pricing (at cost) as directly with Cerebras.
