# Google AI (Gemini) Integration

This integration allows your bot to access the Gemini models from Google AI for content generation and chat completions (LLM).

Usage is charged to the AI Spend of your workspace in Botpress Cloud at the [same pricing](https://ai.google.dev/pricing) (at cost) as directly with Google AI.
