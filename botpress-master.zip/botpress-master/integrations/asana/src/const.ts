export const INTEGRATION_NAME = 'asana'
