import * as bp from '.botpress'
export const bot = new bp.Bot({ actions: {} })
